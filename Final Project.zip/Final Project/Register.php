<?php
session_start();
$user = 'root';
$pass = 'Bombadulce1!';
$db   = 'web_schema';

$dbc = mysqli_connect('localhost',$user,$pass,$db) or die ("Unable to connect");
 
 if (isset($_POST['register_stu'])){

	
	 
	$firstname = mysqli_real_escape_string($dbc, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($dbc, $_POST['lastname']);
	$schoolname = mysqli_real_escape_string($dbc, $_POST['schoolname']);
	//$yearsOfstudy = isset($_POST["yearsOfstudy"]) ?  mysqli_real_escape_string($dbc, $_POST['yearsOfstudy']);
	//echo $yearsOfstudy;
	//$state = $_POST['state'];
	$gender = mysqli_real_escape_string($dbc, $_POST['gender']);
	$username = mysqli_real_escape_string($dbc, $_POST['username']);
	$password = mysqli_real_escape_string($dbc, $_POST['password']);
	$password2 = mysqli_real_escape_string($dbc, $_POST['password2']);
	
	if ($password == $password2) {
		//create user
		$password = md5($password); //Encode password before storing.
		
		$sql = "INSERT INTO `web_schema`.`student`
				(`studentID`,`accID`,`appID`,`firstname`,`lastname`,`gender`,`birthday`,`yearsOfStudy`,
					`schoolName`,`state`,`country`,`username`,`password`,`password2`) 
				VALUES 
				('10 ',null,null,'$firstname','$lastname','$gender','birthday','12','$schoolname',
				' haiti ','country','$username','$password','$password2');";
		mysqli_query($dbc, $sql);
		
		//$fname   = isset($_POST["fname"]) ? mysql_real_escape_string($_POST['fname']) : '';
		
		/* $_SESSION['message'] = "You are now logged in";
		$_SESSION['username'] = $username;
		
		
		
	}else{
		//we failed
	$_SESSION['message'] = "The two passwords do not match";
	} */
	
 }
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 /* 
  $sql = 'SELECT * FROM web_schema.account;';
	
    $result = mysqli_query($dbc, $sql) or die ("Bad SQL: $sql");
  
  if (!$result){

    die(mysqli_error());
  }
 //$data = mysqli_fetch_array($result);

 if(mysqli_num_rows($result) > 0){

	while($row = mysqli_fetch_array($result)){
      echo $row[0]. "<br>";
	  echo $row[1]. "<br>";
	  echo $row[2];
	} */
 //}
 ?>
 
 <br>
 <!--
SELECT * FROM web_schema.account;

SELECT `account`.`accID`,
			`account`.`username`,
			`account`.`password`
		FROM `web_schema`.`account`
		WHERE `account`.`accID` = 1; -->